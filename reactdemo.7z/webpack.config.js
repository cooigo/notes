const path = require('path');
const webpack = require('webpack');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const CheckerPlugin = require('awesome-typescript-loader').CheckerPlugin;
const bundleOutputDir = './build/static';
const glob = require('glob');

function getEntry(globPath) {
    var files = glob.sync(globPath),
        entries = {};
    files.forEach(function (filepath) {
        var paths = filepath.split('/');
        var name = paths.slice(-2, paths.length - 1);
        entries[name] = filepath;
    });

    console.log(entries);
    return entries;

}

const entrys = getEntry('./ClientApp/components/*/index.tsx');
const extractScss = new ExtractTextPlugin({
    filename:'[name]/[name].css',
})

module.exports = (env) => {
    const isDevBuild = !(env && env.prod);
    return [{
        stats: {
            modules: false
        },
        entry: entrys,
        resolve: {
            extensions: ['.js', '.jsx', '.ts', '.tsx']
        },
        output: {
            path: path.join(__dirname, bundleOutputDir),
            filename: '[name]/[name].js',
            publicPath: '/build/static/'
        },
        module: {
            rules: [{
                    test: /\.tsx?$/,
                    use: 'awesome-typescript-loader?silent=true'
                },
                {
                    test: /\.css$/,
                    use: isDevBuild ? ['style-loader', 'css-loader'] : ExtractTextPlugin.extract({
                        use: 'css-loader?minimize'
                    })
                },
                 {
                    test: /\.scss$/,
                    use: extractScss.extract({
                        fallback: 'style-loader',
                        use:[
                            {loader:'css-loader'},
                            {loader:'sass-loader'}
                        ]
                    })
                },
                {
                    test: /\.(png|jpg|jpeg|gif|svg)$/,
                    use: 'url-loader?limit=25000'
                }
            ]
        },
        externals:{
            'react':'React',
            'react-dom':'ReactDOM'
        },
        plugins: [
            extractScss,
            new CheckerPlugin(),
            new webpack.DllReferencePlugin({
                context: __dirname,
                manifest: require('./build/static/vendor-manifest.json')
            })
        ].concat(isDevBuild ? [
            // Plugins that apply in development builds only
            new webpack.SourceMapDevToolPlugin({
                filename: '[file].map', // Remove this line if you prefer inline source maps
                moduleFilenameTemplate: path.relative(bundleOutputDir, '[resourcePath]') // Point sourcemap entries to the original file locations on disk
            })
        ] : [
            // Plugins that apply in production builds only
            new webpack.optimize.UglifyJsPlugin(),
        ])
    }];
};